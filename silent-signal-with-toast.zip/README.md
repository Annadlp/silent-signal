# Silent Signal

A React + Supabase-based system for anonymous reporting of domestic violence cases.

## Features

- Anonymous or identified signal submission
- Repeat detection for high-risk addresses
- Optional media attachment
- Telegram/email alert integration (future)
